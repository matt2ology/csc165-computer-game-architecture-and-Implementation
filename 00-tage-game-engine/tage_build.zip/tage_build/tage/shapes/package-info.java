/**
 * Classes for the various object shapes supported by TAGE.
 *
 * @author Scott Gordon
 */
package tage.shapes;