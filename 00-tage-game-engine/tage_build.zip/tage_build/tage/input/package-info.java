/**
 * For managing input devices such as a gamepad.
 *
 * @author John Clevenger; based on a development version by Russell Bolles
 */
package tage.input;