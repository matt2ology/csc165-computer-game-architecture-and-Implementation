package tage.physics;

public interface PhysicsBallSocketConstraint extends PhysicsConstraint {

}
